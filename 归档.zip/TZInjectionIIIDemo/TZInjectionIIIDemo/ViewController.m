//
//  ViewController.m
//  TZInjectionIIIDemo
//
//  Created by Zou Tan on 2020/7/15.
//  Copyright © 2020 Zou Tan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController()

@property (nonatomic, weak) NSView *hotLoadView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    
    NSView *view = [[NSView alloc] initWithFrame:CGRectMake(100, 100, 200, 200)];
    view.wantsLayer = YES;
    view.layer.backgroundColor = [NSColor redColor].CGColor;
    [self.view addSubview:view];
    self.hotLoadView = view;

}

- (void)injected {
    self.hotLoadView.frame = CGRectMake(10, 20, 10, 100);
    self.hotLoadView.layer.backgroundColor = [NSColor greenColor].CGColor;
    
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
