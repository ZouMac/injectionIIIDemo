//
//  AppDelegate.m
//  TZInjectionIIIDemo
//
//  Created by Zou Tan on 2020/7/15.
//  Copyright © 2020 Zou Tan. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    NSBundle *bundle = [NSBundle bundleWithPath:@"/Applications/InjectionIII.app/Contents/Resources/macOSInjection.bundle"];
    [bundle load];
}
///Users/zoutan/Desktop/InjectionIII.app/Contents/Resources/macOSInjection.bundle

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
