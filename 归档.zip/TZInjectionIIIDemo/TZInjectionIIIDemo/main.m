//
//  main.m
//  TZInjectionIIIDemo
//
//  Created by Zou Tan on 2020/7/15.
//  Copyright © 2020 Zou Tan. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
