//
//  AppDelegate.h
//  TZInjectionIIIIOSDemo
//
//  Created by Zou Tan on 2020/7/15.
//  Copyright © 2020 Zou Tan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

