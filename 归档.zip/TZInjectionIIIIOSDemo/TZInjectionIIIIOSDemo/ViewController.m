//
//  ViewController.m
//  TZInjectionIIIIOSDemo
//
//  Created by Zou Tan on 2020/7/15.
//  Copyright © 2020 Zou Tan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

- (void)injected {
    self.view.backgroundColor = [UIColor whiteColor];
}


@end
